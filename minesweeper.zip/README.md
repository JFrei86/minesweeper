
Copyright Jesse Freitas 2013



Minesweeper Project done as a homework assignment in Spring 2011 for Highschool. This project was later adapted in the Spring of 2013 for a project on artificial intelligence. All code is released under the Creative Commons Attribution-ShareAlike 3.0 License
<img src="http://i.creativecommons.org/l/by-sa/3.0/88x31.png">

When executing this project, please ensure that the executable jar is in the same directory as the pictures in this repository, failure to do so will result in issues displaying the puzzle. This project can be executed by clicking on the JAR file in this repo.
Features of the project include:
  - Artificially intelligent solver
  - Adjustable AI solver speed
  - Manual Play (Disable Solver)
  - 3 Difficulties Default
  - Custom Difficulties Available